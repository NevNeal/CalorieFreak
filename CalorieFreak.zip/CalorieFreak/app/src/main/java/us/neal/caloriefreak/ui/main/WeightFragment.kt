package us.neal.caloriefreak.ui.main

import androidx.fragment.app.Fragment

class WeightFragment : Fragment() {
}