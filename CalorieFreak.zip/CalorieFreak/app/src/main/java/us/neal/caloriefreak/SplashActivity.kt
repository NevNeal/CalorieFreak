package us.neal.caloriefreak

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import androidx.activity.R
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.splash_layout.*

class SplashActivity : AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.splash_layout)

        intent = Intent(this, MainActivity::class.java)

        val animation = AnimationUtils.loadAnimation(this, R.anim.zoom_in)

        animation.setAnimationListener(
            object: Animation.AnimationListener{
                override fun onAnimationRepeat(p0: Animation?) {
                }

                override fun onAnimationEnd(p0: Animation?) {
                    startActivity(intent)
                }

                override fun onAnimationStart(p0: Animation?) {
                }
            }
        )
        imageView.startAnimation(animation)
    }
}