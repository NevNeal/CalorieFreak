package us.neal.caloriefreak.adapters

class CalorieAdapter