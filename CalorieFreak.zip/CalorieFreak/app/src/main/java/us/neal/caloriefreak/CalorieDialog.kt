package us.neal.caloriefreak

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.widget.EditText
import androidx.fragment.app.DialogFragment
import us.neal.caloriefreak.data.CalorieItem
import java.lang.RuntimeException

class CalorieDialog : DialogFragment() {

    interface CalorieItemHandler{
        fun weightItemCreated(calorieItem: CalorieItem)
    }

    private lateinit var calorieItemHandler: CalorieItemHandler
    override fun onAttach(context: Context) {
        super.onAttach(context)

        if (context is CalorieItemHandler) {
            calorieItemHandler = context
        } else {
            throw RuntimeException(
                "The activity does not implement the ItemHandlerInterface" )
        }
    }

    private lateinit var etCalorieName: EditText

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        val builder = AlertDialog.Builder(requireContext())

        builder.setTitle(R.string.calorie_title) //string

        val rootView = requireActivity().layoutInflater.inflate(
            R.layout.new_calorie_dialog, null
        )

        etCalorieName = rootView.etCalorieName

        builder.setView(rootView)

        builder.setPositiveButton(R.string.confirm){
            dialog, witch ->
        }

        return builder.create()
    }

    override fun onResume() {
        super.onResume()

        val positiveButton = (dialog as AlertDialog).getButton(Dialog.BUTTON_POSITIVE)
        positiveButton.setOnClickListener {
            if (etCalorieName.text.isNotEmpty()){
                handleCalorieCreate()
                (dialog as AlertDialog).dismiss()
            } else {
                etCalorieName.error = "This field cannot be empty"
            }
        }

    }

    private fun handleCalorieCreate() {
        calorieItemHandler.weightItemCreated(
            CalorieItem(
                null,
                etCalorieName.text.toString(),
                0
            )
        )
    }



}