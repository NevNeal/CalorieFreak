package us.neal.caloriefreak

class CalorieDialog {
}