package us.neal.caloriefreak

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import us.neal.caloriefreak.data.CalorieItem
import us.neal.caloriefreak.data.WeightItem
import java.lang.RuntimeException

class WeightDialog : DialogFragment() {

    interface WeightItemHandler{
        fun weightItemCreated(weightItem: WeightItem)
    }

    private lateinit var weightItemHandler: WeightItemHandler
    override fun onAttach(context: Context) {
        super.onAttach(context)

        if (context is WeightItemHandler) {
            weightItemHandler = context
        } else {
            throw RuntimeException(
                "The activity does not implement the ItemHandlerInterface" )
        }
    }

    private lateinit var etWeightAmount: EditText

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        val builder = AlertDialog.Builder(requireContext())

        builder.setTitle(R.string.weight_title)

        val rootView = requireActivity().layoutInflater.inflate(
            new_weight_dialog, null
        )

        etWeightAmount = rootView.etWeightAmount

        builder.setView(rootView)

        builder.setPositiveButton(R.string.confirm) {
                dialog, witch ->
        }

        return builder.create()
    }

    override fun onResume() {
        super.onResume()

        val positiveButton = (dialog as AlertDialog).getButton(Dialog.BUTTON_POSITIVE)
        positiveButton.setOnClickListener {
            if (etWeightAmount.text.isNotEmpty()) {
                handleWeightCreate()
                (dialog as AlertDialog).dismiss() //may be broken
            } else {
                etWeightAmount.error = "This field cannot be empty"
            }
        }
    }

    private fun handleWeightCreate() {
        weightItemHandler.weightItemCreated(
            WeightItem(
                null,
                etWeightAmount.text.toString().toInt() //inefficient
            )
        )
    }
}