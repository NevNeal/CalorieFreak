package us.neal.caloriefreak

import androidx.fragment.app.DialogFragment

class WeightDialog : DialogFragment() {


}